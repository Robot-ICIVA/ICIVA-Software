PyImageSearch 4 point Perspective Transformation:
https://www.pyimagesearch.com/2014/08/25/4-point-opencv-getperspective-transform-example/

Referencia Erronea de como Activar la Correccion Subpixel de las esquinas:
https://stackoverflow.com/questions/41051858/arucodetectmarkers-is-not-finding-true-edges-of-markers

Detector Parameter API DOC.
https://docs.opencv.org/3.4.1/d1/dcd/structcv_1_1aruco_1_1DetectorParameters.html

ARUCO API REFERENCE.
https://docs.opencv.org/3.4.0/d9/d6a/group__aruco.html#ga13a2742381c0a48e146d230a8cda2e66

ARUCO OPENCV TUTORIAL.
https://docs.opencv.org/3.4.0/d5/dae/tutorial_aruco_detection.html

Tutorial Básico de Python-Aruco:
http://www.philipzucker.com/aruco-in-opencv/
